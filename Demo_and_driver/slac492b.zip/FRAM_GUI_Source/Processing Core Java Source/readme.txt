For detailed information on the Processing core library, visit
http://code.google.com/p/processing/source/browse/#svn%2Ftrunk%2Fprocessing%2Fcore%2Fsrc%2Fprocessing%2Fcore
